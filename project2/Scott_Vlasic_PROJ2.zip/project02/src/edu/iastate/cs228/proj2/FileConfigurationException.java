package edu.iastate.cs228.proj2;


public class FileConfigurationException extends Exception {
	
	public FileConfigurationException(){
		super();
	}
	
	public FileConfigurationException(String message){
		super(message);
	}
}